@echo off

:: Speed Up PC Tool

:Menu 
cls

echo ======================================
echo 		MAIN MENU
echo ======================================
echo 1. Clear Temporary Files
echo 2. Clear Temporary Internet Files
echo 3. Check Disk For Issues
echo 4. Scan And Restore PC Health
echo 5. End Slow Processes
echo 6. Exit
echo ======================================
set /p choice=Enter your choice [1-6]:
:: Decision-making based choice
if "%choice%"=="1" goto ClearTempFiles
if "%choice%"=="2" goto ClearTempInternetFiles
if "%choice%"=="3" goto CheckDiskForIssues
if "%choice%"=="4" goto ScanAndRestorePCHealth
if "%choice%"=="5" goto EndSlowProcesses
if "%choice%"=="6" goto Exit
echo invalid choice, please try again.
pause
goto Menu

:ClearTempFiles
REM Run a PowerShell script located in the same folder as the batch file
set "SCRIPT=%~dp0ClearTempFiles.ps1"
start powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
REM pause
pause
goto Menu

:ClearTempInternetFiles
set "SCRIPT1=%~dp0ClearTemporaryInternetFiles.ps1"
start powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT1%"
REM pause
pause
goto Menu

:CheckDiskForIssues
set "SCRIPT2=%~dp0CheckDiskForIssues.ps1"
start powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT2%"
REM pause
pause
goto Menu

:ScanAndRestorePCHealth
set "SCRIPT3=%~dp0ScanPCHealth.ps1"
start powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIP3%"
REM pause
pause
goto Menu

:EndSlowProcesses
set "SCRIPT4=%~dp0EndSlowProcesses.ps1"
start powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT4%"
REM pause
pause
goto Menu


:Exit
echo: Good Bye!

